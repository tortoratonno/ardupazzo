SevenSegment
============
SevenSegment is an Arduino Library for **SM41056** 7 Segment Led Display.

![SM41056 Datasheet](https://raw.githubusercontent.com/SalGnt/SevenSegment/master/Extras/SM41056_Datasheet.png)

Usage Instructions
------------------
First of all create an instance of the _SevenSegment_ class

```arduino
SevenSegment sevenSeg(pins, dotPin);
```

and then use the `display(int digit)` function to display a symbol.

```arduino
sevenSeg.display(i);
```

The library provides support for the sixteen hexadecimal symbols. The symbols can be displayed using the numbers `0-15`. A _dash_ will be displayed as default.
    
License
-------
The _SevenSegment_ library was created by [_Salvatore Gentile_](https://twitter.com/_sgentile) and is released under **The MIT License (MIT)**.

    The MIT License (MIT)

    Copyright (c) 2014 Salvatore Gentile

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
